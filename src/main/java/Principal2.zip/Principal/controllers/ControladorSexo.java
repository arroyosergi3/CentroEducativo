package Principal.controllers;

import Principal.entities.Sexo;

public class ControladorSexo extends SuperControlador{
public ControladorSexo(String nombreTabla, Class tipoEntidad) {
		super("sexo", Sexo.class);
		// TODO Auto-generated constructor stub
	}


	
	
}
