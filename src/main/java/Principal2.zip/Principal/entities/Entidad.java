package Principal.entities;

public abstract class Entidad {
	
	
	public Entidad() {
		super();
	}
	
	public abstract int getId();

}
